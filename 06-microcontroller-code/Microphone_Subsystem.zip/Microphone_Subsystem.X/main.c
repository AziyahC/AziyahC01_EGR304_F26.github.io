 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include <xc.h>
#include "mcc_generated_files/system/system.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#define DEBUG_MODE              1
#define THRESHOLD_MODERATE      150
#define THRESHOLD_LOUD          500
#define SAMPLES_PER_WINDOW      2500
#define SAMPLE_DELAY_US         190
#define CALIBRATION_SAMPLES     64

#define LED_D1_ON()             (LATA |= (1 << 0))
#define LED_D1_OFF()            (LATA &= ~(1 << 0))
#define SW1_IS_PRESSED()        ((PORTA & (1 << 4)) == 0)   // RA4
#define SW2_IS_PRESSED()        ((PORTA & (1 << 3)) == 0)   // RA3

// Direct hardware ADC setup & read for RB2 (bypasses MCC ADC bugs)
static void MIC_ADC_Init(void)
{
    TRISB |= (1 << 2);      // RB2 as Input
    ANSELB |= (1 << 2);     // RB2 as Analog
    WPUB &= ~(1 << 2);      // Internal pull-up OFF

    ADCON1 = 0x00;          // Basic mode (clear MCC ADCC modes)
    ADCON2 = 0x00;          // Basic (Legacy) mode
    ADCON3 = 0x00;          // No threshold interrupts
    ADREF  = 0x00;          // VREF+ = VDD, VREF- = VSS (GND)
    ADACQ  = 0x20;          // 32 cycles acquisition time
    ADPCH  = 0x0A;          // Channel = ANB2 (RB2)
    ADCON0 = 0x94;          // ON=1, CS=1 (ADCRC), FM=1 (Right-justified)
}

static uint16_t MIC_ADC_Read(void)
{
    ADCON0bits.GO = 1;
    while (ADCON0bits.GO);
    return ((uint16_t)ADRESH << 8) | ADRESL;
}

int main(void)
{
    SYSTEM_Initialize();

    // Debug LED D1 (RA0)
    TRISA &= ~(1 << 0);
    ANSELA &= ~(1 << 0);
    LED_D1_OFF();

    // Pushbuttons SW1 (RA4) & SW2 (RA3)
    TRISA |= (1 << 3) | (1 << 4);
    ANSELA &= ~((1 << 3) | (1 << 4));
    WPUA |= (1 << 3) | (1 << 4);

    // Initialize ADC directly on RB2
    MIC_ADC_Init();
    __delay_ms(50);

    // Startup baseline calibration
    uint32_t baseline_sum = 0;
    for (uint8_t i = 0; i < CALIBRATION_SAMPLES; i++)
    {
        baseline_sum += MIC_ADC_Read();
        __delay_us(200);
    }
    int16_t quiet_baseline = (int16_t)(baseline_sum / CALIBRATION_SAMPLES);

    uint16_t adc_val = 0;
    int16_t deviation = 0;
    int16_t peak_deviation = 0;

    while (1)
    {
        peak_deviation = 0;

        for (uint16_t i = 0; i < SAMPLES_PER_WINDOW; i++)
        {
            adc_val = MIC_ADC_Read();
            deviation = abs((int16_t)adc_val - quiet_baseline);
            if (deviation > peak_deviation)
            {
                peak_deviation = deviation;
            }
            __delay_us(SAMPLE_DELAY_US);
        }

        if (peak_deviation >= THRESHOLD_MODERATE || SW1_IS_PRESSED() || SW2_IS_PRESSED())
        {
            LED_D1_ON();
        }
        else
        {
            LED_D1_OFF();
        }

        const char *packet;
        if (SW2_IS_PRESSED())                      packet = "T,11";
        else if (SW1_IS_PRESSED())                 packet = "T,10";
        else if (peak_deviation >= THRESHOLD_LOUD) packet = "T,11";
        else if (peak_deviation >= THRESHOLD_MODERATE) packet = "T,10";
        else                                       packet = "T,00";

#if DEBUG_MODE
        printf("%s | raw=%u | base=%d | peak=%d\r\n", packet, adc_val, quiet_baseline, peak_deviation);
#else
        printf("%s\r\n", packet);
#endif
    }

    return 0;
}